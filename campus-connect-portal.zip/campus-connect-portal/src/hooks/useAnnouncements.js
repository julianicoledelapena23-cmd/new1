import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export default function useAnnouncements(category) {
  return useQuery({
    queryKey: ["announcements", category || "all"],
    queryFn: async () => {
      const page = await base44.entities.Announcement.filter(
        category ? { category } : {},
        { sort: "-created_date", limit: 100 }
      );
      return page.items.sort((a, b) => {
        if (Boolean(b.pinned) !== Boolean(a.pinned)) return Number(b.pinned) - Number(a.pinned);
        return new Date(b.created_date).getTime() - new Date(a.created_date).getTime();
      });
    },
  });
}