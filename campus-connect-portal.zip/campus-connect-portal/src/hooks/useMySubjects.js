import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";

export default function useMySubjects() {
  const { user } = useAuth();
  const email = user?.email;

  const query = useQuery({
    queryKey: ["my-subjects", email],
    enabled: Boolean(email),
    queryFn: async () => {
      const [enrollmentPage, subjectPage] = await Promise.all([
        base44.entities.Enrollment.filter({ student_email: email }, { limit: 100 }),
        base44.entities.Subject.list({ limit: 200 }),
      ]);
      const byId = new Map(subjectPage.items.map((subject) => [subject.id, subject]));
      return enrollmentPage.items
        .map((enrollment) => ({ enrollment, subject: byId.get(enrollment.subject_id) }))
        .filter((row) => row.subject && row.enrollment.status !== "dropped");
    },
  });

  return { ...query, rows: query.data || [] };
}