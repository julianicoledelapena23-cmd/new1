import { useEffect, useState } from "react";
import { ALL_WEEKDAYS } from "@/lib/format";

export default function useToday() {
  const [day, setDay] = useState("");
  const [label, setLabel] = useState("");

  useEffect(() => {
    const now = new Date();
    setDay(ALL_WEEKDAYS[now.getDay()]);
    setLabel(now.toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" }));
  }, []);

  return { day, label };
}