import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import PageHeader from "@/components/PageHeader";
import EmptyState from "@/components/EmptyState";
import AnnouncementCard from "@/components/announcements/AnnouncementCard";
import useAnnouncements from "@/hooks/useAnnouncements";
import { cn } from "@/lib/utils";

const FILTERS = ["all", "academic", "enrollment", "event", "deadline", "facilities"];

export const Route = createFileRoute("/_authed/announcements")({
  component: AnnouncementsPage,
  head: () => ({ meta: [{ title: "Announcements · Campus Connect Portal" }] }),
});

function AnnouncementsPage() {
  const [filter, setFilter] = useState("all");
  const { data, isLoading } = useAnnouncements(filter === "all" ? null : filter);

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        eyebrow="Campus bulletin"
        title="Announcements"
        description="Official notices from the registrar, student affairs and other campus offices."
      />

      <div className="flex flex-wrap gap-1.5">
        {FILTERS.map((item) => (
          <button
            key={item}
            onClick={() => setFilter(item)}
            className={cn(
              "rounded-full border px-3.5 py-1.5 text-[12px] font-medium capitalize transition-colors",
              filter === item
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card text-muted-foreground hover:bg-muted"
            )}
          >
            {item}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="grid gap-3">
          {[0, 1, 2].map((item) => (
            <div key={item} className="h-32 animate-pulse rounded-[24px] border border-border bg-card" />
          ))}
        </div>
      ) : data?.length ? (
        <div className="grid gap-3">
          {data.map((announcement) => (
            <AnnouncementCard key={announcement.id} announcement={announcement} />
          ))}
        </div>
      ) : (
        <EmptyState
          title="Nothing posted here yet"
          description="New notices from the campus offices will show up in this feed."
        />
      )}
    </div>
  );
}