import { createFileRoute, Link } from "@tanstack/react-router";
import { useAuth } from "@/lib/AuthContext";
import DashboardHome from "@/components/dashboard/DashboardHome";
import TodaySchedule from "@/components/dashboard/TodaySchedule";
import EmptyState from "@/components/EmptyState";
import useMySubjects from "@/hooks/useMySubjects";
import useAnnouncements from "@/hooks/useAnnouncements";
import useToday from "@/hooks/useToday";
import { WEEKDAYS, formatTime, sortByStart, subjectHours, timeAgo, toMinutes } from "@/lib/format";

export const Route = createFileRoute("/_authed/")({
  component: DashboardPage,
  head: () => ({ meta: [{ title: "Dashboard · Campus Connect Portal" }] }),
});

function DashboardPage() {
  const { user } = useAuth();
  const { day, label } = useToday();
  const { rows, isLoading } = useMySubjects();
  const { data: announcements = [] } = useAnnouncements();

  const firstName = (user?.full_name || "").split(" ")[0];
  const subjects = rows.map((row) => row.subject);
  const units = subjects.reduce((sum, subject) => sum + (Number(subject.units) || 0), 0);
  const weeklyHours = subjects.reduce((sum, subject) => sum + subjectHours(subject), 0);

  const todayClasses = (day ? subjects.filter((subject) => subject.days?.includes(day)) : []).sort(sortByStart);
  const now = new Date();
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  const nextClass = todayClasses.find((subject) => toMinutes(subject.start_time) > nowMinutes) || todayClasses[0];

  const gradedRows = rows.filter(
    (row) => row.enrollment.grade && !Number.isNaN(Number(row.enrollment.grade))
  );
  const gradedUnits = gradedRows.reduce((sum, row) => sum + (Number(row.subject.units) || 0), 0);
  const gradeTotal = gradedRows.reduce(
    (sum, row) => sum + Number(row.enrollment.grade) * (Number(row.subject.units) || 0),
    0
  );
  const gwa = gradedUnits ? (gradeTotal / gradedUnits).toFixed(2) : "—";
  const bestGrade = gradedRows.length
    ? Math.min(...gradedRows.map((row) => Number(row.enrollment.grade))).toFixed(2)
    : "—";
  const ringPct = rows.length ? Math.round((gradedRows.length / rows.length) * 100) : 0;

  const bars = WEEKDAYS.slice(0, 6).map((weekday) => ({
    label: weekday.slice(0, 2),
    value: subjects
      .filter((subject) => subject.days?.includes(weekday))
      .reduce((sum, subject) => sum + Math.max((toMinutes(subject.end_time) - toMinutes(subject.start_time)) / 60, 0), 0),
  }));

  const gradePoints = gradedRows.map((row) => ({
    label: row.subject.code,
    value: Number(row.enrollment.grade),
  }));

  const scheduleItems = todayClasses.map((subject) => ({
    code: subject.code,
    title: subject.title,
    start: formatTime(subject.start_time),
    end: formatTime(subject.end_time),
    room: subject.room || "TBA",
  }));

  const feed = announcements.slice(0, 4).map((announcement) => ({
    label: announcement.office || announcement.category || "Campus",
    detail: announcement.title,
    time: timeAgo(announcement.created_date),
  }));

  return (
    <div className="flex flex-col gap-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
            {label || "Today"}
          </p>
          <h1 className="mt-1 font-display text-3xl tracking-tight sm:text-4xl">
            Welcome back{firstName ? `, ${firstName}` : ""}
          </h1>
        </div>
        <p className="max-w-xs text-sm text-muted-foreground">
          {subjects[0]?.term || "Current semester"} · Your classes, subjects and campus news in one place.
        </p>
      </header>

      {isLoading ? (
        <div className="h-80 animate-pulse rounded-[36px] border border-border bg-card" />
      ) : rows.length === 0 ? (
        <EmptyState
          title="Your semester is not set up yet"
          description="The registrar has not enrolled you in any subject. Send them a message and your schedule will appear here."
          action={
            <Link to="/messages" className="rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
              Message the registrar
            </Link>
          }
        />
      ) : (
        <DashboardHome
          title="Semester overview"
          hero={{
            kicker: "Units enrolled",
            value: units,
            delta: `${subjects.length} ${subjects.length === 1 ? "subject" : "subjects"}`,
            note: `${weeklyHours.toFixed(1)} class hours each week`,
            ringPct,
          }}
          load={{
            title: "Weekly load",
            sub: "Class hours by day",
            bars,
            stats: [
              { k: "Subjects", v: String(subjects.length) },
              { k: "Hours", v: weeklyHours.toFixed(1) },
              { k: "Next", v: nextClass ? formatTime(nextClass.start_time) : "Free" },
            ],
          }}
          grades={{
            title: "Grades",
            sub: "Posted so far this term",
            points: gradePoints,
            stats: [
              { k: "GWA", v: gwa },
              { k: "Best", v: bestGrade },
              { k: "Posted", v: `${gradedRows.length}/${rows.length}` },
            ],
          }}
          feed={feed}
        />
      )}

      <div className="grid gap-6 lg:grid-cols-[1.15fr_1fr]">
        <TodaySchedule items={scheduleItems} title={day ? `Today · ${day}` : "Today's classes"} />

        <section className="rounded-[28px] border border-border bg-card p-5 sm:p-6">
          <h2 className="font-display text-lg tracking-tight">Quick links</h2>
          <p className="mt-1 text-sm text-muted-foreground">Jump straight to the pages students use most.</p>
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            {[
              { label: "My subjects", meta: `${rows.length} enrolled`, to: "/subjects" },
              { label: "Weekly schedule", meta: `${weeklyHours.toFixed(1)} hrs`, to: "/schedule" },
              { label: "Announcements", meta: `${announcements.length} posted`, to: "/announcements" },
              { label: "Message the office", meta: "Registrar", to: "/messages" },
            ].map((link) => (
              <Link
                key={link.label}
                to={link.to}
                className="rounded-2xl border border-border bg-background/60 px-4 py-3 transition-colors hover:border-primary/40"
              >
                <p className="text-sm font-semibold">{link.label}</p>
                <p className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">{link.meta}</p>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}