import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { toast } from "sonner";
import PageHeader from "@/components/PageHeader";
import EmptyState from "@/components/EmptyState";
import AdminTabs from "@/components/admin/AdminTabs";
import EnrollForm from "@/components/admin/EnrollForm";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authed/admin/enrollments")({
  component: AdminEnrollmentsPage,
  head: () => ({ meta: [{ title: "Admin · Enrollments" }] }),
});

function AdminEnrollmentsPage() {
  const { user } = useAuth();
  const [formOpen, setFormOpen] = useState(false);
  const queryClient = useQueryClient();

  const { data: subjects = [] } = useQuery({
    queryKey: ["subjects"],
    queryFn: async () => {
      const page = await base44.entities.Subject.list({ sort: "code", limit: 200 });
      return page.items;
    },
  });

  const { data: enrollments = [], isLoading } = useQuery({
    queryKey: ["enrollments"],
    queryFn: async () => {
      const page = await base44.entities.Enrollment.list({ sort: "-created_date", limit: 300 });
      return page.items;
    },
  });

  const remove = async (enrollment) => {
    if (!window.confirm(`Remove ${enrollment.student_email} from ${enrollment.subject_code || "this subject"}?`)) return;
    try {
      await base44.entities.Enrollment.delete(enrollment.id);
      await queryClient.invalidateQueries({ queryKey: ["enrollments"] });
      await queryClient.invalidateQueries({ queryKey: ["my-subjects"] });
      toast.success("Enrollment removed");
    } catch (error) {
      toast.error(error?.message || "Could not remove the enrollment");
    }
  };

  if (user && user.role !== "admin") {
    return <EmptyState title="Admins only" description="This area is limited to campus administrators." />;
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        eyebrow="Class lists"
        title="Enrollments"
        description="Match students to subjects using the email they sign in with."
        action={
          <Button className="rounded-full" onClick={() => setFormOpen(true)}>
            <Plus className="mr-1.5 h-4 w-4" /> Enroll student
          </Button>
        }
      />

      <AdminTabs />

      {isLoading ? (
        <div className="h-40 animate-pulse rounded-[24px] border border-border bg-card" />
      ) : enrollments.length === 0 ? (
        <EmptyState title="No enrollments yet" description="Enroll your first student to build a class list." />
      ) : (
        <div className="overflow-hidden rounded-[24px] border border-border bg-card">
          <table className="w-full text-left text-sm">
            <thead className="bg-muted/60 text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
              <tr>
                <th className="px-4 py-2.5 font-semibold">Student</th>
                <th className="px-4 py-2.5 font-semibold">Subject</th>
                <th className="hidden px-4 py-2.5 font-semibold sm:table-cell">Section</th>
                <th className="px-4 py-2.5 font-semibold">Grade</th>
                <th className="px-4 py-2.5" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {enrollments.map((enrollment) => (
                <tr key={enrollment.id}>
                  <td className="px-4 py-3">
                    <p className="font-medium">{enrollment.student_name || "Student"}</p>
                    <p className="text-xs text-muted-foreground">{enrollment.student_email}</p>
                  </td>
                  <td className="px-4 py-3">{enrollment.subject_code || "—"}</td>
                  <td className="hidden px-4 py-3 text-muted-foreground sm:table-cell">{enrollment.section || "—"}</td>
                  <td className="px-4 py-3">{enrollment.grade || "—"}</td>
                  <td className="px-4 py-3 text-right">
                    <Button size="icon" variant="ghost" aria-label="Remove enrollment" onClick={() => remove(enrollment)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <EnrollForm open={formOpen} onOpenChange={setFormOpen} subjects={subjects} />
    </div>
  );
}