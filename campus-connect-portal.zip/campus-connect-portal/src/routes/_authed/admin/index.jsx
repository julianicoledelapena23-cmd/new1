import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { Pencil, Pin, Plus, Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { toast } from "sonner";
import PageHeader from "@/components/PageHeader";
import EmptyState from "@/components/EmptyState";
import AdminTabs from "@/components/admin/AdminTabs";
import AnnouncementForm from "@/components/announcements/AnnouncementForm";
import useAnnouncements from "@/hooks/useAnnouncements";
import { Button } from "@/components/ui/button";
import { formatDate } from "@/lib/format";

export const Route = createFileRoute("/_authed/admin/")({
  component: AdminAnnouncementsPage,
  head: () => ({ meta: [{ title: "Admin · Announcements" }] }),
});

function AdminAnnouncementsPage() {
  const { user } = useAuth();
  const { data = [], isLoading } = useAnnouncements();
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const queryClient = useQueryClient();

  const remove = async (announcement) => {
    if (!window.confirm(`Delete "${announcement.title}"?`)) return;
    try {
      await base44.entities.Announcement.delete(announcement.id);
      await queryClient.invalidateQueries({ queryKey: ["announcements"] });
      toast.success("Announcement deleted");
    } catch (error) {
      toast.error(error?.message || "Could not delete the announcement");
    }
  };

  if (user && user.role !== "admin") {
    return <EmptyState title="Admins only" description="This area is limited to campus administrators." />;
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        eyebrow="Campus office"
        title="Announcements"
        description="Publish notices that every student sees in their portal."
        action={
          <Button
            className="rounded-full"
            onClick={() => {
              setEditing(null);
              setFormOpen(true);
            }}
          >
            <Plus className="mr-1.5 h-4 w-4" /> New announcement
          </Button>
        }
      />

      <AdminTabs />

      {isLoading ? (
        <div className="h-40 animate-pulse rounded-[24px] border border-border bg-card" />
      ) : data.length === 0 ? (
        <EmptyState title="No announcements yet" description="Publish the first notice for students." />
      ) : (
        <div className="grid gap-2">
          {data.map((announcement) => (
            <article
              key={announcement.id}
              className="flex flex-wrap items-start gap-3 rounded-[20px] border border-border bg-card p-4"
            >
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                  <span>{announcement.category}</span>
                  {announcement.pinned ? (
                    <span className="inline-flex items-center gap-1 text-primary">
                      <Pin className="h-2.5 w-2.5" /> pinned
                    </span>
                  ) : null}
                  <span className="normal-case tracking-normal">
                    {announcement.office || "Campus office"} · {formatDate(announcement.published_on || announcement.created_date)}
                  </span>
                </div>
                <h3 className="mt-1 font-display text-base leading-snug">{announcement.title}</h3>
                <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{announcement.body}</p>
              </div>
              <div className="flex gap-1">
                <Button
                  size="icon"
                  variant="ghost"
                  aria-label="Edit announcement"
                  onClick={() => {
                    setEditing(announcement);
                    setFormOpen(true);
                  }}
                >
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button size="icon" variant="ghost" aria-label="Delete announcement" onClick={() => remove(announcement)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </article>
          ))}
        </div>
      )}

      <AnnouncementForm open={formOpen} onOpenChange={setFormOpen} initial={editing} />
    </div>
  );
}