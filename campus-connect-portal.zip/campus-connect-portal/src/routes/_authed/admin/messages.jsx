import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Reply } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import PageHeader from "@/components/PageHeader";
import EmptyState from "@/components/EmptyState";
import AdminTabs from "@/components/admin/AdminTabs";
import ReplyDialog from "@/components/admin/ReplyDialog";
import { Button } from "@/components/ui/button";
import { timeAgo } from "@/lib/format";

export const Route = createFileRoute("/_authed/admin/messages")({
  component: AdminMessagesPage,
  head: () => ({ meta: [{ title: "Admin · Inbox" }] }),
});

function AdminMessagesPage() {
  const { user } = useAuth();
  const [active, setActive] = useState(null);

  const { data: messages = [], isLoading } = useQuery({
    queryKey: ["admin-messages"],
    queryFn: async () => {
      const page = await base44.entities.Message.list({ sort: "-created_date", limit: 200 });
      return page.items;
    },
  });

  if (user && user.role !== "admin") {
    return <EmptyState title="Admins only" description="This area is limited to campus administrators." />;
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        eyebrow="Student messages"
        title="Inbox"
        description="Concerns sent from student portals. Replies show up in the student's messages page."
      />

      <AdminTabs />

      {isLoading ? (
        <div className="h-40 animate-pulse rounded-[24px] border border-border bg-card" />
      ) : messages.length === 0 ? (
        <EmptyState title="Inbox is clear" description="No student messages yet." />
      ) : (
        <div className="grid gap-2">
          {messages.map((message) => (
            <article key={message.id} className="rounded-[20px] border border-border bg-card p-4">
              <div className="flex flex-wrap items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                <span className="rounded-full bg-secondary px-2 py-0.5">{message.office}</span>
                <span>{message.status}</span>
                <span className="ml-auto normal-case tracking-normal">{timeAgo(message.created_date)}</span>
              </div>
              <h3 className="mt-1.5 font-display text-base leading-snug">{message.subject}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{message.body}</p>
              <p className="mt-1.5 text-xs text-muted-foreground">
                {message.sender_name || "Student"} · {message.sender_email}
              </p>
              {message.reply ? (
                <p className="mt-3 rounded-xl border border-primary/15 bg-primary/[0.05] px-3 py-2 text-sm">
                  <span className="text-[10px] font-semibold uppercase tracking-[0.14em] text-primary">Replied</span>
                  <span className="mt-1 block">{message.reply}</span>
                </p>
              ) : null}
              <Button size="sm" variant="outline" className="mt-3 rounded-full" onClick={() => setActive(message)}>
                <Reply className="mr-1.5 h-3.5 w-3.5" /> {message.reply ? "Edit reply" : "Reply"}
              </Button>
            </article>
          ))}
        </div>
      )}

      <ReplyDialog open={Boolean(active)} onOpenChange={(open) => !open && setActive(null)} message={active} />
    </div>
  );
}