import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { toast } from "sonner";
import PageHeader from "@/components/PageHeader";
import EmptyState from "@/components/EmptyState";
import AdminTabs from "@/components/admin/AdminTabs";
import SubjectForm from "@/components/admin/SubjectForm";
import { Button } from "@/components/ui/button";
import { scheduleLabel } from "@/lib/format";

export const Route = createFileRoute("/_authed/admin/subjects")({
  component: AdminSubjectsPage,
  head: () => ({ meta: [{ title: "Admin · Subjects" }] }),
});

function AdminSubjectsPage() {
  const { user } = useAuth();
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const queryClient = useQueryClient();

  const { data: subjects = [], isLoading } = useQuery({
    queryKey: ["subjects"],
    queryFn: async () => {
      const page = await base44.entities.Subject.list({ sort: "code", limit: 200 });
      return page.items;
    },
  });

  const remove = async (subject) => {
    if (!window.confirm(`Delete ${subject.code}? Enrollments will need to be updated.`)) return;
    try {
      await base44.entities.Subject.delete(subject.id);
      await queryClient.invalidateQueries({ queryKey: ["subjects"] });
      await queryClient.invalidateQueries({ queryKey: ["my-subjects"] });
      toast.success("Subject deleted");
    } catch (error) {
      toast.error(error?.message || "Could not delete the subject");
    }
  };

  if (user && user.role !== "admin") {
    return <EmptyState title="Admins only" description="This area is limited to campus administrators." />;
  }

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        eyebrow="Catalog"
        title="Subjects"
        description="The master list of subjects offered this term."
        action={
          <Button
            className="rounded-full"
            onClick={() => {
              setEditing(null);
              setFormOpen(true);
            }}
          >
            <Plus className="mr-1.5 h-4 w-4" /> New subject
          </Button>
        }
      />

      <AdminTabs />

      {isLoading ? (
        <div className="h-40 animate-pulse rounded-[24px] border border-border bg-card" />
      ) : subjects.length === 0 ? (
        <EmptyState title="No subjects yet" description="Add the subjects students can enroll in this term." />
      ) : (
        <div className="grid gap-2">
          {subjects.map((subject) => (
            <article
              key={subject.id}
              className="flex flex-wrap items-center gap-3 rounded-[20px] border border-border bg-card p-4"
            >
              <div className="min-w-0 flex-1">
                <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                  {subject.code} · {subject.units || 0} units
                </p>
                <h3 className="mt-0.5 font-display text-base leading-snug">{subject.title}</h3>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  {subject.instructor || "No instructor"} · {subject.room || "No room"} · {scheduleLabel(subject)}
                </p>
              </div>
              <div className="flex gap-1">
                <Button
                  size="icon"
                  variant="ghost"
                  aria-label="Edit subject"
                  onClick={() => {
                    setEditing(subject);
                    setFormOpen(true);
                  }}
                >
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button size="icon" variant="ghost" aria-label="Delete subject" onClick={() => remove(subject)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </article>
          ))}
        </div>
      )}

      <SubjectForm open={formOpen} onOpenChange={setFormOpen} initial={editing} />
    </div>
  );
}