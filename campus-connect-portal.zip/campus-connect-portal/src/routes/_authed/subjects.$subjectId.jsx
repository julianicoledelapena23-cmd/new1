import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, Clock, MapPin, User } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import EmptyState from "@/components/EmptyState";
import useMySubjects from "@/hooks/useMySubjects";
import { WEEKDAYS, formatTime, scheduleLabel } from "@/lib/format";

export const Route = createFileRoute("/_authed/subjects/$subjectId")({
  component: SubjectDetailPage,
  head: () => ({ meta: [{ title: "Subject · Campus Connect Portal" }] }),
});

function SubjectDetailPage() {
  const { subjectId } = Route.useParams();
  const { rows, isLoading } = useMySubjects();
  const row = rows.find((item) => item.subject.id === subjectId);

  if (isLoading) {
    return <div className="h-64 animate-pulse rounded-[28px] border border-border bg-card" />;
  }

  if (!row) {
    return (
      <EmptyState
        title="Subject not found"
        description="This subject may have been removed from your enrollment."
        action={
          <Link to="/subjects" className="rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
            Back to subjects
          </Link>
        }
      />
    );
  }

  const { subject, enrollment } = row;

  return (
    <div className="flex flex-col gap-6">
      <Link to="/subjects" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> All subjects
      </Link>

      <PageHeader eyebrow={subject.code} title={subject.title} description={subject.description} />

      <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <section className="rounded-[24px] border border-border bg-card p-5 sm:p-6">
          <h2 className="font-display text-lg tracking-tight">Class details</h2>
          <dl className="mt-4 grid gap-4 sm:grid-cols-2">
            <div>
              <dt className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Instructor</dt>
              <dd className="mt-1 flex items-center gap-1.5 text-sm">
                <User className="h-3.5 w-3.5 text-muted-foreground" />
                {subject.instructor || "To be announced"}
              </dd>
            </div>
            <div>
              <dt className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Room</dt>
              <dd className="mt-1 flex items-center gap-1.5 text-sm">
                <MapPin className="h-3.5 w-3.5 text-muted-foreground" />
                {subject.room || "To be announced"}
              </dd>
            </div>
            <div>
              <dt className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Schedule</dt>
              <dd className="mt-1 flex items-center gap-1.5 text-sm">
                <Clock className="h-3.5 w-3.5 text-muted-foreground" />
                {scheduleLabel(subject)}
              </dd>
            </div>
            <div>
              <dt className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Units</dt>
              <dd className="mt-1 text-sm">{subject.units || 0} units</dd>
            </div>
          </dl>

          <div className="mt-6">
            <h3 className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Weekly meetings</h3>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {WEEKDAYS.map((day) => {
                const meets = subject.days?.includes(day);
                return (
                  <span
                    key={day}
                    className={
                      meets
                        ? "rounded-full bg-primary/10 px-3 py-1.5 text-xs font-medium text-primary"
                        : "rounded-full border border-border px-3 py-1.5 text-xs text-muted-foreground/60"
                    }
                  >
                    {day.slice(0, 3)}
                    {meets ? ` · ${formatTime(subject.start_time)}` : ""}
                  </span>
                );
              })}
            </div>
          </div>
        </section>

        <section className="flex flex-col gap-4">
          <div className="rounded-[24px] border border-border bg-card p-5 sm:p-6">
            <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Your grade</p>
            <p className="mt-2 font-display text-4xl tracking-tight">{enrollment.grade || "—"}</p>
            <p className="mt-1 text-xs text-muted-foreground">
              {enrollment.grade ? "Posted by your instructor" : "Not posted yet this term"}
            </p>
          </div>
          <div className="rounded-[24px] border border-border bg-card p-5 sm:p-6">
            <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Section</p>
            <p className="mt-2 text-lg font-medium">{enrollment.section || subject.section || "—"}</p>
            <p className="mt-1 text-xs text-muted-foreground">{subject.term || "Current term"}</p>
            <p className="mt-4 text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">Standing</p>
            <p className="mt-1 text-sm capitalize">{enrollment.status || "enrolled"}</p>
          </div>
        </section>
      </div>
    </div>
  );
}