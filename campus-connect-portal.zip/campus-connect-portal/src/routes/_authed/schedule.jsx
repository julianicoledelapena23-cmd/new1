import { createFileRoute } from "@tanstack/react-router";
import PageHeader from "@/components/PageHeader";
import EmptyState from "@/components/EmptyState";
import WeekGrid from "@/components/schedule/WeekGrid";
import useMySubjects from "@/hooks/useMySubjects";
import { WEEKDAYS, formatTime, sortByStart } from "@/lib/format";

export const Route = createFileRoute("/_authed/schedule")({
  component: SchedulePage,
  head: () => ({ meta: [{ title: "Schedule · Campus Connect Portal" }] }),
});

function SchedulePage() {
  const { rows, isLoading } = useMySubjects();
  const subjects = rows.map((row) => row.subject);

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        eyebrow="Weekly timetable"
        title="My schedule"
        description="Every class meeting this semester, arranged by day."
      />

      {isLoading ? (
        <div className="h-72 animate-pulse rounded-[28px] border border-border bg-card" />
      ) : subjects.length === 0 ? (
        <EmptyState title="No classes scheduled" description="Your timetable fills in once you are enrolled in subjects." />
      ) : (
        <>
          <section className="hidden rounded-[28px] border border-border bg-card p-5 sm:block">
            <WeekGrid subjects={subjects} />
          </section>

          <div className="grid gap-3 sm:hidden">
            {WEEKDAYS.map((day) => {
              const classes = subjects.filter((subject) => subject.days?.includes(day)).sort(sortByStart);
              return (
                <section key={day} className="rounded-[22px] border border-border bg-card p-4">
                  <div className="flex items-baseline justify-between">
                    <h2 className="font-display text-base tracking-tight">{day}</h2>
                    <span className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                      {classes.length} {classes.length === 1 ? "class" : "classes"}
                    </span>
                  </div>
                  {classes.length === 0 ? (
                    <p className="mt-2 text-xs text-muted-foreground">No classes</p>
                  ) : (
                    <ul className="mt-2 divide-y divide-border">
                      {classes.map((subject) => (
                        <li key={subject.id} className="flex items-start gap-3 py-2.5">
                          <span className="w-[58px] shrink-0 text-xs tabular-nums text-primary">
                            {formatTime(subject.start_time)}
                          </span>
                          <div className="min-w-0">
                            <p className="truncate text-sm font-medium">{subject.title}</p>
                            <p className="text-[11px] text-muted-foreground">
                              {subject.code} · {subject.room || "TBA"}
                            </p>
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                </section>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}