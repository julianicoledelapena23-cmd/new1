import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Plus } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import PageHeader from "@/components/PageHeader";
import EmptyState from "@/components/EmptyState";
import MessageThread from "@/components/messages/MessageThread";
import ComposeDialog from "@/components/messages/ComposeDialog";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authed/messages")({
  component: MessagesPage,
  head: () => ({ meta: [{ title: "Messages · Campus Connect Portal" }] }),
});

function MessagesPage() {
  const { user } = useAuth();
  const [composeOpen, setComposeOpen] = useState(false);

  const { data: messages = [], isLoading } = useQuery({
    queryKey: ["my-messages", user?.email],
    enabled: Boolean(user?.email),
    queryFn: async () => {
      const page = await base44.entities.Message.filter(
        { sender_email: user.email },
        { sort: "-created_date", limit: 100 }
      );
      return page.items;
    },
  });

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        eyebrow="Talk to the campus offices"
        title="Messages"
        description="Send a concern to the registrar, finance, student affairs or IT support and track the reply here."
        action={
          <Button onClick={() => setComposeOpen(true)} className="rounded-full">
            <Plus className="mr-1.5 h-4 w-4" /> New message
          </Button>
        }
      />

      {isLoading ? (
        <div className="h-40 animate-pulse rounded-[24px] border border-border bg-card" />
      ) : messages.length ? (
        <div className="grid gap-3">
          {messages.map((message) => (
            <MessageThread key={message.id} message={message} />
          ))}
        </div>
      ) : (
        <EmptyState
          title="No messages yet"
          description="Questions about records, tuition or your schedule? Send the first message and an office will reply here."
          action={
            <Button onClick={() => setComposeOpen(true)} className="rounded-full">
              Write a message
            </Button>
          }
        />
      )}

      <ComposeDialog open={composeOpen} onOpenChange={setComposeOpen} />
    </div>
  );
}