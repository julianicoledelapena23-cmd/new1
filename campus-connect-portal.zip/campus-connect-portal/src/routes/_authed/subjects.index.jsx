import { createFileRoute, Link } from "@tanstack/react-router";
import PageHeader from "@/components/PageHeader";
import EmptyState from "@/components/EmptyState";
import SubjectCard from "@/components/subjects/SubjectCard";
import useMySubjects from "@/hooks/useMySubjects";

export const Route = createFileRoute("/_authed/subjects/")({
  component: SubjectsPage,
  head: () => ({ meta: [{ title: "My subjects · Campus Connect Portal" }] }),
});

function SubjectsPage() {
  const { rows, isLoading } = useMySubjects();
  const units = rows.reduce((sum, row) => sum + (Number(row.subject.units) || 0), 0);

  return (
    <div className="flex flex-col gap-6">
      <PageHeader
        eyebrow="This semester"
        title="My subjects"
        description={
          rows.length
            ? `${rows.length} subjects · ${units} units enrolled. Open a subject to see its schedule, room and grade.`
            : "Your enrolled subjects will appear here."
        }
      />

      {isLoading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[0, 1, 2].map((item) => (
            <div key={item} className="h-44 animate-pulse rounded-[24px] border border-border bg-card" />
          ))}
        </div>
      ) : rows.length ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {rows.map((row) => (
            <SubjectCard key={row.enrollment.id} subject={row.subject} enrollment={row.enrollment} />
          ))}
        </div>
      ) : (
        <EmptyState
          title="No subjects enrolled yet"
          description="Once the registrar adds you to a class, it shows up here with its schedule and instructor."
          action={
            <Link
              to="/messages"
              className="rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
            >
              Message the registrar
            </Link>
          }
        />
      )}
    </div>
  );
}