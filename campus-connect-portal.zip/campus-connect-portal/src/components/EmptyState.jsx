export default function EmptyState({ title, description, action }) {
  return (
    <div className="rounded-[24px] border border-dashed border-border bg-card/60 px-6 py-12 text-center">
      <p className="font-display text-lg tracking-tight">{title}</p>
      {description ? <p className="mx-auto mt-1 max-w-md text-sm text-muted-foreground">{description}</p> : null}
      {action ? <div className="mt-4 flex justify-center">{action}</div> : null}
    </div>
  );
}