import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { OFFICES } from "@/lib/format";

export default function ComposeDialog({ open, onOpenChange }) {
  const { user } = useAuth();
  const [office, setOffice] = useState(OFFICES[0]);
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const queryClient = useQueryClient();

  const submit = async (event) => {
    event.preventDefault();
    if (!subject.trim() || !body.trim()) {
      toast.error("Add a subject and message first.");
      return;
    }
    setSending(true);
    try {
      await base44.entities.Message.create({
        sender_email: user?.email,
        sender_name: user?.full_name || user?.email,
        office,
        subject: subject.trim(),
        body: body.trim(),
        status: "open",
      });
      await queryClient.invalidateQueries({ queryKey: ["my-messages"] });
      toast.success(`Message sent to ${office}`);
      setSubject("");
      setBody("");
      onOpenChange(false);
    } catch (error) {
      toast.error(error?.message || "Could not send the message");
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Message the school</DialogTitle>
          <DialogDescription>Pick an office and we will route your concern there.</DialogDescription>
        </DialogHeader>

        <form onSubmit={submit} className="grid gap-4">
          <div className="grid gap-1.5">
            <Label>Office</Label>
            <Select value={office} onValueChange={setOffice}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {OFFICES.map((item) => (
                  <SelectItem key={item} value={item}>
                    {item}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="m-subject">Subject</Label>
            <Input id="m-subject" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Request for certificate of enrollment" />
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="m-body">Message</Label>
            <Textarea id="m-body" rows={5} value={body} onChange={(e) => setBody(e.target.value)} placeholder="Write your concern with any details the office needs…" />
          </div>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={sending}>
              {sending ? "Sending…" : "Send message"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}