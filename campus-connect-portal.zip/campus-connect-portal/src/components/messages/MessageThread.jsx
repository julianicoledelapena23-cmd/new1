import { formatDate, timeAgo } from "@/lib/format";

const STATUS_STYLE = {
  open: "bg-[#f6ecd2] text-[#7a5b12]",
  replied: "bg-primary/10 text-primary",
  closed: "bg-muted text-muted-foreground",
};

export default function MessageThread({ message }) {
  return (
    <article className="rounded-[24px] border border-border bg-card p-5 sm:p-6">
      <div className="flex flex-wrap items-center gap-2">
        <span className="rounded-full bg-secondary px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
          {message.office}
        </span>
        <span className={`rounded-full px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] ${STATUS_STYLE[message.status] || STATUS_STYLE.open}`}>
          {message.status}
        </span>
        <span className="ml-auto text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
          {timeAgo(message.created_date)}
        </span>
      </div>

      <h3 className="mt-3 font-display text-lg leading-snug tracking-tight">{message.subject}</h3>
      <p className="mt-1 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">{message.body}</p>
      <p className="mt-2 text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
        From {message.sender_name || message.sender_email}
      </p>

      {message.reply ? (
        <div className="mt-4 rounded-2xl border border-primary/15 bg-primary/[0.05] p-4">
          <p className="text-[10px] font-semibold uppercase tracking-[0.16em] text-primary">
            Reply · {message.replied_by || message.office}
            {message.replied_on ? ` · ${formatDate(message.replied_on)}` : ""}
          </p>
          <p className="mt-1.5 whitespace-pre-line text-sm leading-relaxed">{message.reply}</p>
        </div>
      ) : (
        <p className="mt-4 rounded-2xl border border-dashed border-border px-4 py-3 text-xs text-muted-foreground">
          Waiting for a reply from the {message.office} office.
        </p>
      )}
    </article>
  );
}