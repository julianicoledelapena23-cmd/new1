import { Link, useRouterState } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

const TABS = [
  { to: "/admin", label: "Announcements" },
  { to: "/admin/subjects", label: "Subjects" },
  { to: "/admin/enrollments", label: "Enrollments" },
  { to: "/admin/messages", label: "Inbox" },
];

export default function AdminTabs() {
  const pathname = useRouterState({ select: (state) => state.location.pathname });

  return (
    <div className="flex flex-wrap gap-1.5 rounded-full border border-border bg-card p-1.5">
      {TABS.map((tab) => (
        <Link
          key={tab.to}
          to={tab.to}
          className={cn(
            "rounded-full px-3.5 py-1.5 text-[13px] font-medium transition-colors",
            pathname === tab.to ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted"
          )}
        >
          {tab.label}
        </Link>
      ))}
    </div>
  );
}