import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { WEEKDAYS } from "@/lib/format";
import { cn } from "@/lib/utils";

const EMPTY = {
  code: "",
  title: "",
  description: "",
  units: 3,
  instructor: "",
  section: "",
  room: "",
  days: [],
  start_time: "08:00",
  end_time: "09:30",
  term: "Second Semester, AY 2026-2027",
};

export default function SubjectForm({ open, onOpenChange, initial }) {
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (open) setForm(initial ? { ...EMPTY, ...initial } : EMPTY);
  }, [open, initial]);

  const set = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));
  const toggleDay = (day) =>
    set("days", form.days.includes(day) ? form.days.filter((item) => item !== day) : [...form.days, day]);

  const submit = async (event) => {
    event.preventDefault();
    if (!form.code.trim() || !form.title.trim()) {
      toast.error("Course code and title are required.");
      return;
    }
    setSaving(true);
    try {
      const payload = { ...form, units: Number(form.units) || 0 };
      if (initial?.id) {
        await base44.entities.Subject.update(initial.id, payload);
      } else {
        await base44.entities.Subject.create(payload);
      }
      await queryClient.invalidateQueries({ queryKey: ["subjects"] });
      await queryClient.invalidateQueries({ queryKey: ["my-subjects"] });
      toast.success(initial?.id ? "Subject updated" : "Subject added");
      onOpenChange(false);
    } catch (error) {
      toast.error(error?.message || "Could not save the subject");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">{initial?.id ? "Edit subject" : "New subject"}</DialogTitle>
          <DialogDescription>Subjects appear in the catalog and in student schedules.</DialogDescription>
        </DialogHeader>

        <form onSubmit={submit} className="grid gap-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label htmlFor="s-code">Course code</Label>
              <Input id="s-code" value={form.code} onChange={(e) => set("code", e.target.value)} placeholder="IT 201" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="s-units">Units</Label>
              <Input id="s-units" type="number" min="0" step="0.5" value={form.units} onChange={(e) => set("units", e.target.value)} />
            </div>
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="s-title">Title</Label>
            <Input id="s-title" value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="Data Structures and Algorithms" />
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="s-desc">Description</Label>
            <Textarea id="s-desc" rows={3} value={form.description || ""} onChange={(e) => set("description", e.target.value)} placeholder="What the subject covers…" />
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            <div className="grid gap-1.5">
              <Label htmlFor="s-instructor">Instructor</Label>
              <Input id="s-instructor" value={form.instructor} onChange={(e) => set("instructor", e.target.value)} placeholder="Prof. R. Santos" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="s-section">Section</Label>
              <Input id="s-section" value={form.section} onChange={(e) => set("section", e.target.value)} placeholder="BSIT-2A" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="s-room">Room</Label>
              <Input id="s-room" value={form.room} onChange={(e) => set("room", e.target.value)} placeholder="Lab 2" />
            </div>
          </div>

          <div className="grid gap-1.5">
            <Label>Days</Label>
            <div className="flex flex-wrap gap-1.5">
              {WEEKDAYS.map((day) => (
                <button
                  key={day}
                  type="button"
                  onClick={() => toggleDay(day)}
                  className={cn(
                    "rounded-full border px-3 py-1.5 text-xs font-medium transition-colors",
                    form.days.includes(day)
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border text-muted-foreground hover:bg-muted"
                  )}
                >
                  {day.slice(0, 3)}
                </button>
              ))}
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label htmlFor="s-start">Starts</Label>
              <Input id="s-start" type="time" value={form.start_time} onChange={(e) => set("start_time", e.target.value)} />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="s-end">Ends</Label>
              <Input id="s-end" type="time" value={form.end_time} onChange={(e) => set("end_time", e.target.value)} />
            </div>
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="s-term">Term</Label>
            <Input id="s-term" value={form.term} onChange={(e) => set("term", e.target.value)} />
          </div>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving…" : initial?.id ? "Save changes" : "Add subject"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}