import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function ReplyDialog({ open, onOpenChange, message }) {
  const { user } = useAuth();
  const [reply, setReply] = useState("");
  const [saving, setSaving] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (open) setReply(message?.reply || "");
  }, [open, message]);

  const submit = async (event) => {
    event.preventDefault();
    if (!reply.trim()) {
      toast.error("Write a reply first.");
      return;
    }
    setSaving(true);
    try {
      await base44.entities.Message.update(message.id, {
        reply: reply.trim(),
        replied_by: user?.full_name || "School office",
        replied_on: new Date().toISOString().slice(0, 10),
        status: "replied",
      });
      await queryClient.invalidateQueries({ queryKey: ["admin-messages"] });
      toast.success("Reply sent");
      onOpenChange(false);
    } catch (error) {
      toast.error(error?.message || "Could not send the reply");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Reply to {message?.sender_name || "student"}</DialogTitle>
          <DialogDescription>{message?.subject}</DialogDescription>
        </DialogHeader>

        <form onSubmit={submit} className="grid gap-4">
          <div className="rounded-2xl border border-border bg-background/60 p-4 text-sm text-muted-foreground">
            {message?.body}
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="r-reply">Your reply</Label>
            <Textarea id="r-reply" rows={5} value={reply} onChange={(e) => setReply(e.target.value)} placeholder="Write the office response…" />
          </div>
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Sending…" : "Send reply"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}