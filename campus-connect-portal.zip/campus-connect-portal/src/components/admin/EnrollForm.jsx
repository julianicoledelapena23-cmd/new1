import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function EnrollForm({ open, onOpenChange, subjects = [] }) {
  const [subjectId, setSubjectId] = useState("");
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [section, setSection] = useState("");
  const [grade, setGrade] = useState("");
  const [saving, setSaving] = useState(false);
  const queryClient = useQueryClient();

  const submit = async (event) => {
    event.preventDefault();
    if (!subjectId || !email.trim()) {
      toast.error("Choose a subject and enter the student email.");
      return;
    }
    setSaving(true);
    try {
      const subject = subjects.find((item) => item.id === subjectId);
      await base44.entities.Enrollment.create({
        subject_id: subjectId,
        subject_code: subject?.code || "",
        student_email: email.trim().toLowerCase(),
        student_name: name.trim() || email.trim(),
        section: section.trim() || subject?.section || "",
        grade: grade.trim(),
        status: "enrolled",
      });
      await queryClient.invalidateQueries({ queryKey: ["enrollments"] });
      toast.success("Student enrolled");
      setEmail("");
      setName("");
      setSection("");
      setGrade("");
      onOpenChange(false);
    } catch (error) {
      toast.error(error?.message || "Could not enroll the student");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Enroll a student</DialogTitle>
          <DialogDescription>Use the email the student signs in with so the subject appears on their portal.</DialogDescription>
        </DialogHeader>

        <form onSubmit={submit} className="grid gap-4">
          <div className="grid gap-1.5">
            <Label>Subject</Label>
            <Select value={subjectId} onValueChange={setSubjectId}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a subject" />
              </SelectTrigger>
              <SelectContent>
                {subjects.map((subject) => (
                  <SelectItem key={subject.id} value={subject.id}>
                    {subject.code} — {subject.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="e-email">Student email</Label>
            <Input id="e-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="student@school.edu" />
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="e-name">Student name</Label>
            <Input id="e-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Maria Santos" />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label htmlFor="e-section">Section</Label>
              <Input id="e-section" value={section} onChange={(e) => setSection(e.target.value)} placeholder="BSIT-2A" />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="e-grade">Grade (optional)</Label>
              <Input id="e-grade" value={grade} onChange={(e) => setGrade(e.target.value)} placeholder="1.50" />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Enrolling…" : "Enroll student"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}