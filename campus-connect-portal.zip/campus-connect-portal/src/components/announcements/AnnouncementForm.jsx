import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const CATEGORIES = ["academic", "enrollment", "event", "deadline", "facilities"];
const EMPTY = { title: "", body: "", category: "academic", office: "", published_on: "", pinned: false };

export default function AnnouncementForm({ open, onOpenChange, initial }) {
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (open) setForm(initial ? { ...EMPTY, ...initial } : EMPTY);
  }, [open, initial]);

  const set = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  const submit = async (event) => {
    event.preventDefault();
    if (!form.title.trim() || !form.body.trim()) {
      toast.error("Add a title and message first.");
      return;
    }
    setSaving(true);
    try {
      const payload = { ...form, published_on: form.published_on || new Date().toISOString().slice(0, 10) };
      if (initial?.id) {
        await base44.entities.Announcement.update(initial.id, payload);
      } else {
        await base44.entities.Announcement.create(payload);
      }
      await queryClient.invalidateQueries({ queryKey: ["announcements"] });
      toast.success(initial?.id ? "Announcement updated" : "Announcement published");
      onOpenChange(false);
    } catch (error) {
      toast.error(error?.message || "Could not save the announcement");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {initial?.id ? "Edit announcement" : "New announcement"}
          </DialogTitle>
          <DialogDescription>Students see this in the announcements feed right away.</DialogDescription>
        </DialogHeader>

        <form onSubmit={submit} className="grid gap-4">
          <div className="grid gap-1.5">
            <Label htmlFor="a-title">Title</Label>
            <Input id="a-title" value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="Enrollment closes Friday" />
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="a-body">Message</Label>
            <Textarea id="a-body" rows={5} value={form.body} onChange={(e) => set("body", e.target.value)} placeholder="Details students need to know…" />
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-1.5">
              <Label>Category</Label>
              <Select value={form.category} onValueChange={(value) => set("category", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((category) => (
                    <SelectItem key={category} value={category} className="capitalize">
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-1.5">
              <Label htmlFor="a-office">Office</Label>
              <Input id="a-office" value={form.office} onChange={(e) => set("office", e.target.value)} placeholder="Registrar" />
            </div>

            <div className="grid gap-1.5">
              <Label htmlFor="a-date">Publish date</Label>
              <Input id="a-date" type="date" value={form.published_on || ""} onChange={(e) => set("published_on", e.target.value)} />
            </div>

            <div className="flex items-end justify-between gap-3 rounded-xl border border-border px-3 py-2.5">
              <div>
                <p className="text-sm font-medium">Pin to top</p>
                <p className="text-xs text-muted-foreground">Keep it above other posts</p>
              </div>
              <Switch checked={Boolean(form.pinned)} onCheckedChange={(value) => set("pinned", value)} />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving…" : initial?.id ? "Save changes" : "Publish"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}