import { Pin } from "lucide-react";
import { formatDate, timeAgo } from "@/lib/format";

const DOT = {
  academic: "bg-primary",
  enrollment: "bg-[#6b5bb5]",
  event: "bg-[#b98a2e]",
  deadline: "bg-[#c1503f]",
  facilities: "bg-[#5b6b7a]",
};

export default function AnnouncementCard({ announcement }) {
  return (
    <article className="rounded-[24px] border border-border bg-card p-5 sm:p-6">
      <div className="flex flex-wrap items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <span className={`h-1.5 w-1.5 rounded-full ${DOT[announcement.category] || "bg-primary"}`} />
          {announcement.category || "general"}
        </span>
        {announcement.pinned ? (
          <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2 py-0.5 text-primary">
            <Pin className="h-2.5 w-2.5" /> Pinned
          </span>
        ) : null}
        <span className="ml-auto normal-case tracking-normal text-muted-foreground">
          {announcement.office || "Campus office"} ·{" "}
          {announcement.published_on ? formatDate(announcement.published_on) : timeAgo(announcement.created_date)}
        </span>
      </div>

      <h2 className="mt-3 font-display text-xl leading-snug tracking-tight">{announcement.title}</h2>
      <p className="mt-2 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">{announcement.body}</p>
    </article>
  );
}