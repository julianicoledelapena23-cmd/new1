import { MapPin } from "lucide-react";
import { WEEKDAYS, formatTime, sortByStart } from "@/lib/format";

export default function WeekGrid({ subjects = [] }) {
  const columns = WEEKDAYS.map((day) => ({
    day,
    classes: subjects.filter((subject) => subject.days?.includes(day)).sort(sortByStart),
  }));

  return (
    <div className="overflow-x-auto">
      <div className="grid min-w-[760px] grid-cols-6 gap-3">
        {columns.map(({ day, classes }) => (
          <div key={day} className="flex flex-col gap-2">
            <p className="px-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-muted-foreground">
              {day.slice(0, 3)}
            </p>
            <div className="flex min-h-[180px] flex-col gap-2 rounded-2xl border border-border bg-background/50 p-2">
              {classes.length === 0 ? (
                <p className="px-1 pt-2 text-[11px] text-muted-foreground/70">Free</p>
              ) : (
                classes.map((subject) => (
                  <div key={`${subject.id}-${day}`} className="rounded-xl border border-primary/15 bg-primary/[0.06] p-2.5">
                    <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-primary">{subject.code}</p>
                    <p className="mt-1 text-[12px] font-medium leading-snug">{subject.title}</p>
                    <p className="mt-1 text-[11px] text-muted-foreground">
                      {formatTime(subject.start_time)}–{formatTime(subject.end_time)}
                    </p>
                    <p className="mt-0.5 flex items-center gap-1 text-[11px] text-muted-foreground">
                      <MapPin className="h-2.5 w-2.5" />
                      {subject.room || "TBA"}
                    </p>
                  </div>
                ))
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}