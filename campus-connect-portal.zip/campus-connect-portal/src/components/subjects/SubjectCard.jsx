import { Link } from "@tanstack/react-router";
import { MapPin, User } from "lucide-react";
import { scheduleLabel } from "@/lib/format";

export default function SubjectCard({ subject, enrollment }) {
  return (
    <Link
      to="/subjects/$subjectId"
      params={{ subjectId: subject.id }}
      className="flex flex-col gap-3 rounded-[24px] border border-border bg-card p-5 transition-all hover:border-primary/40 hover:shadow-[0_16px_40px_-32px_rgba(19,26,36,0.6)]"
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">{subject.code}</p>
          <h3 className="mt-1 font-display text-lg leading-snug tracking-tight">{subject.title}</h3>
        </div>
        {enrollment?.grade ? (
          <span className="shrink-0 rounded-full bg-primary/10 px-2.5 py-1 text-xs font-semibold text-primary">
            {enrollment.grade}
          </span>
        ) : null}
      </div>

      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <User className="h-3.5 w-3.5" />
          {subject.instructor || "TBA"}
        </span>
        <span className="inline-flex items-center gap-1.5">
          <MapPin className="h-3.5 w-3.5" />
          {subject.room || "TBA"}
        </span>
      </div>

      <p className="mt-auto border-t border-border pt-3 text-xs text-muted-foreground">{scheduleLabel(subject)}</p>
    </Link>
  );
}