import { useEffect, useState } from "react";

export default function CountUp({ value = 0, prefix = "", suffix = "", decimals = 0 }) {
  const [shown, setShown] = useState(value);

  useEffect(() => {
    if (typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) {
      setShown(value);
      return;
    }
    let frame;
    const start = performance.now();
    const step = (ts) => {
      const p = Math.min((ts - start) / 900, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setShown(value * eased);
      if (p < 1) frame = requestAnimationFrame(step);
    };
    frame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frame);
  }, [value]);

  const text = Number(shown || 0).toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });

  return (
    <span>
      {prefix}
      {text}
      {suffix}
    </span>
  );
}