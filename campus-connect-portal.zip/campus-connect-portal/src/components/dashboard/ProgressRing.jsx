import CountUp from "./CountUp";

export default function ProgressRing({ pct = 0, on = false }) {
  const r = 34;
  const circumference = 2 * Math.PI * r;
  const target = circumference - (circumference * pct) / 100;

  return (
    <div
      className="relative aspect-square w-[56px] shrink-0 sm:w-[66px]"
      role="img"
      aria-label={`${pct} percent of the semester complete`}
    >
      <svg viewBox="0 0 80 80" className="h-full w-full -rotate-90">
        <circle cx="40" cy="40" r={r} fill="none" strokeWidth="6" className="stroke-primary/15" />
        <circle
          cx="40"
          cy="40"
          r={r}
          fill="none"
          strokeWidth="6"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={on ? target : circumference}
          className="stroke-primary transition-[stroke-dashoffset] duration-[1200ms] ease-out"
        />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center text-xs font-semibold sm:text-sm">
        <CountUp value={pct} suffix="%" />
      </span>
    </div>
  );
}