export default function LoadCard({ title, sub, bars = [], stats = [], on = false }) {
  const max = Math.max(...bars.map((b) => b.value), 1);

  return (
    <article className="flex flex-col gap-4 rounded-[24px] border border-border bg-card p-5">
      <div>
        <h3 className="text-[11px] font-semibold uppercase tracking-[0.18em]">{title}</h3>
        <p className="text-xs text-muted-foreground">{sub}</p>
      </div>

      <div className="flex items-end gap-[6px]" aria-hidden="true">
        {bars.map((bar, i) => (
          <div key={`${bar.label}-${i}`} className="flex flex-1 flex-col items-center gap-1.5">
            <div className="flex h-12 w-full items-end">
              <div
                className="w-full origin-bottom rounded-t-[3px] bg-primary/75 transition-transform duration-700 ease-out"
                style={{
                  height: `${Math.max((bar.value / max) * 100, 6)}%`,
                  transform: on ? "scaleY(1)" : "scaleY(0)",
                  transitionDelay: `${i * 45}ms`,
                }}
              />
            </div>
            <span className="text-[9px] uppercase tracking-wider text-muted-foreground">{bar.label}</span>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap gap-x-6 gap-y-3">
        {stats.map((stat) => (
          <div key={stat.k}>
            <span className="block text-[9px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
              {stat.k}
            </span>
            <span className="font-display text-lg leading-tight">{stat.v}</span>
          </div>
        ))}
      </div>
    </article>
  );
}