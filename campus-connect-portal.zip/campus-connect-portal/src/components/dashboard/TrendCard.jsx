function buildPath(points) {
  if (points.length < 2) return { d: "", last: null };
  const values = points.map((p) => p.value);
  const max = Math.max(...values);
  const min = Math.min(...values);
  const span = Math.max(max - min, 1);
  const width = 200;
  const height = 64;
  const pad = 8;

  const coords = points.map((point, i) => {
    const x = pad + (i * (width - pad * 2)) / (points.length - 1);
    const y = height - pad - ((point.value - min) / span) * (height - pad * 2);
    return { x: Number(x.toFixed(1)), y: Number(y.toFixed(1)) };
  });

  const d = coords
    .map((coord, i) => `${i === 0 ? "M" : "L"}${coord.x},${coord.y}`)
    .join(" ");

  return { d, last: coords[coords.length - 1] };
}

export default function TrendCard({ title, sub, points = [], stats = [], on = false }) {
  const { d, last } = buildPath(points);

  return (
    <article className="flex flex-col gap-4 rounded-[24px] border border-border bg-card p-5">
      <div>
        <h3 className="text-[11px] font-semibold uppercase tracking-[0.18em]">{title}</h3>
        <p className="text-xs text-muted-foreground">{sub}</p>
      </div>

      {points.length > 1 ? (
        <svg viewBox="0 0 200 64" className="h-[72px] w-full overflow-visible" aria-hidden="true">
          <line x1="4" y1="12" x2="196" y2="12" className="stroke-border" strokeWidth="1" />
          <line x1="4" y1="32" x2="196" y2="32" className="stroke-border" strokeWidth="1" />
          <line x1="4" y1="52" x2="196" y2="52" className="stroke-border" strokeWidth="1" />
          <path
            d={d}
            pathLength="1"
            strokeDasharray="1"
            strokeDashoffset={on ? 0 : 1}
            className="fill-none stroke-primary transition-[stroke-dashoffset] duration-[1200ms] ease-out"
            strokeWidth="2.4"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {last ? (
            <circle cx={last.x} cy={last.y} r="3.2" className="fill-card stroke-primary" strokeWidth="2.4" />
          ) : null}
        </svg>
      ) : (
        <p className="flex h-[72px] items-center justify-center rounded-xl border border-dashed border-border text-xs text-muted-foreground">
          Grades appear once your instructors post them.
        </p>
      )}

      <div className="flex flex-wrap gap-x-6 gap-y-3">
        {stats.map((stat) => (
          <div key={stat.k}>
            <span className="block text-[9px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
              {stat.k}
            </span>
            <span className="font-display text-lg leading-tight">{stat.v}</span>
          </div>
        ))}
      </div>
    </article>
  );
}