import useEnter from "@/hooks/useEnter";
import CountUp from "./CountUp";
import ProgressRing from "./ProgressRing";
import LoadCard from "./LoadCard";
import TrendCard from "./TrendCard";
import BulletinFeed from "./BulletinFeed";

export default function DashboardHome({ title, hero, load, grades, feed }) {
  const on = useEnter(90);

  return (
    <section className="rounded-[28px] border border-border bg-[#FBFAF5] p-3.5 sm:rounded-[36px] sm:p-4">
      <div className="flex flex-col gap-4">
        <header className="px-1 pt-1 text-center">
          <h2 className="font-display text-2xl tracking-tight sm:text-3xl">{title}</h2>
        </header>

        <div className="grid items-center gap-3 rounded-[24px] border border-primary/15 bg-primary/[0.05] px-5 py-4 sm:rounded-[36px] sm:px-7 sm:py-5 md:grid-cols-[auto_1fr_auto] md:gap-6">
          <div className="flex items-center justify-between gap-4 md:block">
            <div>
              <span className="text-[10px] font-semibold uppercase tracking-[0.2em] text-muted-foreground">
                {hero.kicker}
              </span>
              <p className="font-display text-4xl leading-none tracking-tight sm:text-5xl">
                <CountUp
                  value={hero.value}
                  prefix={hero.prefix}
                  suffix={hero.suffix}
                  decimals={hero.decimals}
                />
              </p>
            </div>
            <div className="md:hidden">
              <ProgressRing pct={hero.ringPct} on={on} />
            </div>
          </div>

          <p className="flex flex-wrap items-baseline gap-x-2.5 gap-y-1 text-sm">
            <span className="font-semibold text-primary">{hero.delta}</span>
            <span className="text-muted-foreground">{hero.note}</span>
          </p>

          <div className="hidden md:block">
            <ProgressRing pct={hero.ringPct} on={on} />
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <LoadCard {...load} on={on} />
          <TrendCard {...grades} on={on} />
        </div>

        <BulletinFeed items={feed} />
      </div>
    </section>
  );
}