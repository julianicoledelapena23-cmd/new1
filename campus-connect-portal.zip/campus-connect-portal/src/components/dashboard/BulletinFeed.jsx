export default function BulletinFeed({ items = [] }) {
  if (!items.length) {
    return (
      <div className="rounded-[24px] border border-dashed border-border px-5 py-8 text-center text-sm text-muted-foreground">
        No campus updates yet.
      </div>
    );
  }

  return (
    <ul className="m-0 list-none p-0">
      {items.map((item, i) => (
        <li
          key={`${item.label}-${i}`}
          className="grid grid-cols-[1fr_auto] items-center gap-x-4 gap-y-0.5 border-t border-border px-1 py-2.5 first:border-t-0 sm:grid-cols-[calc(50%-12px)_minmax(0,1fr)_auto] sm:gap-x-5"
        >
          <span className="text-[11px] font-semibold uppercase tracking-[0.14em]">{item.label}</span>
          <span className="col-span-2 min-w-0 truncate text-[13px] text-muted-foreground sm:col-span-1">
            {item.detail}
          </span>
          <span className="justify-self-end whitespace-nowrap text-[11px] uppercase tracking-[0.1em] text-muted-foreground sm:justify-self-start">
            {item.time}
          </span>
        </li>
      ))}
    </ul>
  );
}