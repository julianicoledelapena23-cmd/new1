import { useEffect, useState } from "react";
import { Clock, MapPin } from "lucide-react";

export default function TodaySchedule({ items = [], title = "Today's classes" }) {
  return (
    <section className="rounded-[28px] border border-border bg-card p-5 sm:p-6">
      <div className="mb-4 flex items-baseline justify-between gap-4">
        <h2 className="font-display text-lg tracking-tight">{title}</h2>
        <span className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
          {items.length} {items.length === 1 ? "class" : "classes"}
        </span>
      </div>

      {items.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-border px-4 py-8 text-center text-sm text-muted-foreground">
          No classes scheduled today. Enjoy the breather.
        </p>
      ) : (
        <ul className="m-0 list-none divide-y divide-border p-0">
          {items.map((item) => (
            <li key={item.code + item.start} className="flex items-start gap-4 py-3.5 first:pt-0 last:pb-0">
              <span className="mt-0.5 w-[62px] shrink-0 font-display text-sm tabular-nums text-primary">
                {item.start}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{item.title}</p>
                <p className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1">
                    <Clock className="h-3 w-3" /> {item.start} – {item.end}
                  </span>
                  <span className="inline-flex items-center gap-1">
                    <MapPin className="h-3 w-3" /> {item.room}
                  </span>
                </p>
              </div>
              <span className="shrink-0 rounded-full bg-secondary px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">
                {item.code}
              </span>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

export function useTodayLabel() {
  const [label, setLabel] = useState("");
  useEffect(() => {
    setLabel(
      new Date().toLocaleDateString("en-US", {
        weekday: "long",
        month: "long",
        day: "numeric",
      })
    );
  }, []);
  return label;
}